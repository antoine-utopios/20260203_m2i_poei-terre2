number_a = int(input("Enter the first number: "))
number_b = int(input("Enter the second number: "))

print(f"{number_a} + {number_b} = {number_a + number_b}")
